-- CreateIndex
CREATE INDEX "approval_workflows_name_idx" ON "approval_workflows"("name");

-- CreateIndex
CREATE INDEX "approval_workflows_description_idx" ON "approval_workflows"("description");
