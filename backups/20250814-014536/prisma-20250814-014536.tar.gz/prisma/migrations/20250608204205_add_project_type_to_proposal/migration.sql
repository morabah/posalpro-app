-- AlterTable
ALTER TABLE "proposals" ADD COLUMN     "projectType" TEXT;
